# Everything Upgrade Balatro
Everything Upgrade Balatro (EUB) adds the following:
- 49 Jokers 
- 1 Tarot
- 2 Spectrals
- 12 Currency Cards 
- 3 Decks
- 3 Vouchers
- 2 Enhancements
- 2 Editions
- 3 Seals
- 10 Booster Packs 

This mods mechanics are based on Everything Upgrade Tree and adds fun strategies and combos to score more chips then vanilla. (my highscore is double e) 
This is a Content Mod
A balance of Chaos and Vanilla+
Most art in this mod is made by me and from EUT
All of the below is my art:
- Seals
- Currency Packs
- HunterJ360 (self insert smh)
- Vouchers
- Decks
- Currency Cards
- Tarots and Spectrals
- Goog Cards
All of the below is EUT art:
- 48 Jokers (excluding HunterJ360)
- Joker Packs (slightly edited by me to fit Balatro)

Also the BGM used for HunterJ360 is Call of the Void: Phase 3a, one left.
# Extras
This mod **REQUIRES** Talisman and Steammodded and is not built to be played with other mods (ex: Cryptid Value Changing)

Please report any bugs to my forums in Cryptid, Balatro, Balatro CLAMS, and Everything Upgrade Tree Discord Servers.
**EUT art was authorized to be used by EUT's current Owner Unby6 and the Illustrator Jiskin**

# Credits
Unby6 - Owner of EUT
Jiskin the Banana - Illustrator for almost all the Jokers and Packs
